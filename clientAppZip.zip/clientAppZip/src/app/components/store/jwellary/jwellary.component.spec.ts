import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JwellaryComponent } from './jwellary.component';

describe('JwellaryComponent', () => {
  let component: JwellaryComponent;
  let fixture: ComponentFixture<JwellaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JwellaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JwellaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
