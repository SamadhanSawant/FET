import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jwellary',
  templateUrl: './jwellary.component.html',
  styleUrls: ['./jwellary.component.css']
})
export class JwellaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
