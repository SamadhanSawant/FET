import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CartComponent } from './components/cart/cart.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { ProductsComponent } from './components/products/products.component';
import { RegisterComponent } from './components/register/register.component';
import { AllproductsComponent } from './components/store/allproducts/allproducts.component';
import { ElectronicsComponent } from './components/store/electronics/electronics.component';
import { FashionComponent } from './components/store/fashion/fashion.component';
import { JwellaryComponent } from './components/store/jwellary/jwellary.component';
import { StoreComponent } from './components/store/store.component';


const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'home', component: HomeComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'cart', component: CartComponent },
  { path: 'store', component: StoreComponent },
  { path: 'electronics', component: ElectronicsComponent },
  { path: 'allproducts', component: AllproductsComponent },
  { path: 'fashion', component: FashionComponent },
  { path: 'jwellary', component: JwellaryComponent },
  { path: 'products', component: ProductsComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

