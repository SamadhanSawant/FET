export interface Orders {
   totalPrice: Number;
   cartCreditedDate: Date;
   orderPlacedDate: Date;

}