import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Orders } from '../Models/User';

@Injectable({
  providedIn: 'root'
})
export class CheckoutService {

  baseURL: string;

  constructor(private http: HttpClient) {
    this.baseURL = '/api/CheckOut/';
  }

  placeOrder(userId: number, checkedOutItems: Orders) {
    return this.http.post<number>(this.baseURL + `${userId}`, checkedOutItems);
  }
}
